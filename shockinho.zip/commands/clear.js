const Discord = require("discord.js");

exports.run = async (bot, message, args) => {
    let user = message.author.username
  if (!message.member.permissions.has("MANAGE_MESSAGES"))
    return message.reply(
      "🚨 | Ops, parece que você não tem permissão de ADMINISTRADOR para limpar o chat, :("
    );
    
  const deleteCount = parseInt(args[0], 10);
  if (!deleteCount || deleteCount < 1 || deleteCount > 99)
    return message.reply(
        "🚨 | forneça um número de até **99 mensagens** a serem excluídas."
      );

  const fetched = await message.channel.messages.fetch({
    limit: deleteCount + 1
  });
  message.channel.bulkDelete(fetched); {
      let embed = new Discord.MessageEmbed()
      .setDescription(`**♻️ O chat foi apagado, F.**`)
      .setColor('BLUE')
      .setTitle('`CLEAR`')
      .setThumbnail('https://static.wixstatic.com/media/3d17d2_612743c0be8140a0a63a9ca09ab2e6bd~mv2.gif')
      .setFooter(`• Chat foi limp por: ${message.author.username}`, message.author.displayAvatarURL({format: "png"}));
      await message.channel.send(embed); 
  }
};