const Discord = require("discord.js");

exports.run = (client, message, args) => {
    const embed = new Discord.MessageEmbed()
    .setColor('#7e0000')
    .setDescription(` **LISTA DE COMANDOS DO Shockinho** ${message.author}`)
    .setTimestamp()
    .setFooter(` Comando dado por: ${message.author.username} `)
    .addFields(
        {
            name: '.avatar',
            value: `Comando que mostra o seu avatar ou de outras pessoas que você mencionar.`,
           
        },
                {
            name: '.say',
            value: `Comando usado para avisos/anuncios ou até zueiras onde o Shockinho ira repitir quando dado o comando. (APENAS PARA ADMINISTRADOS)`,
        
        },
        {
            name: '.clear',
            value: `Comando de limpar o chat (APENAS PARA ADMINISTRADORES)`,
           
        },
    )
    message.channel.send(embed);
}